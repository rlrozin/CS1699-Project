# 1530-LiftingApp
1530 group project Lifting Application

By Angel Chang, Robert Rozin, Abhi Inuganti, Drew Kozak, Andrew McLaren
